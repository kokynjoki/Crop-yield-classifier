from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# ==============================
# Load trained model, scaler and encoder
# ==============================
try:
    model = joblib.load("best_yield_model.joblib")
    scaler = joblib.load("scaler.joblib")
    encoder = joblib.load("label_encoder.joblib")   # NEW

    print("✅ Model, Scaler and Label Encoder loaded successfully!")

except Exception as e:
    model = None
    scaler = None
    encoder = None
    print(f"⚠️ Loading Error: {e}")


# ==============================
# Input Validation
# ==============================
def validate_inputs(ph, cec, oc, tn, p, k,
                    clay, silt, sand,
                    altitude, acres):

    errors = []

    if not (3 <= ph <= 10):
        errors.append("Soil pH should be between 3 and 10.")

    if cec < 0:
        errors.append("CEC cannot be negative.")

    if oc < 0:
        errors.append("Organic Carbon cannot be negative.")

    if tn < 0:
        errors.append("Total Nitrogen cannot be negative.")

    if p < 0:
        errors.append("Phosphorus cannot be negative.")

    if k < 0:
        errors.append("Potassium cannot be negative.")

    if altitude < 0:
        errors.append("Altitude cannot be negative.")

    if acres <= 0:
        errors.append("Field size must be greater than zero.")

    texture_sum = clay + silt + sand

    if abs(texture_sum - 100) > 3:
        errors.append(
            f"Soil texture percentages should total approximately 100%. "
            f"Current total = {texture_sum}%."
        )

    return errors


@app.route("/", methods=["GET", "POST"])
def index():

    prediction = None
    advice = None
    bg_color = None

    if request.method == "POST":

        try:

            ph = float(request.form["ph"])
            cec = float(request.form["cec"])
            oc = float(request.form["oc"])
            tn = float(request.form["tn"])
            p = float(request.form["p"])
            k = float(request.form["k"])
            clay = float(request.form["clay"])
            silt = float(request.form["silt"])
            sand = float(request.form["sand"])
            altitude = float(request.form["altitude"])
            acres = float(request.form["acres"])

            # ======================
            # Validate Inputs
            # ======================

            validation_errors = validate_inputs(
                ph, cec, oc, tn, p, k,
                clay, silt, sand,
                altitude, acres
            )

            if validation_errors:

                prediction = "Invalid Input"

                advice = "<br>".join(validation_errors)

                bg_color = "danger"

                return render_template(
                    "index.html",
                    prediction=prediction,
                    advice=advice,
                    bg_color=bg_color
                )

            # ======================
            # Feature Array
            # ======================

            features = np.array([[
                ph,
                cec,
                oc,
                tn,
                p,
                k,
                clay,
                silt,
                sand,
                altitude,
                acres
            ]])

            print("\n========================")
            print("Raw Features")
            print(features)

            # ======================
            # Prediction
            # ======================

            if model is not None and scaler is not None and encoder is not None:

                features_scaled = scaler.transform(features)

                print("\nScaled Features")
                print(features_scaled)

                raw_prediction = model.predict(features_scaled)

                print("\nRaw Prediction")
                print(raw_prediction)

                prediction = encoder.inverse_transform(raw_prediction)[0]

                print("Decoded Prediction:", prediction)

            else:

                prediction = "Model Not Available"

            # ======================
            # Advisory
            # ======================

            pred = prediction.lower()

            if "high" in pred:

                bg_color = "success"

                advice = (
                    "Excellent soil fertility detected. "
                    "Maintain current nutrient levels through balanced fertilization, "
                    "timely weed control, and proper moisture management."
                )

            elif "moderate" in pred:

                bg_color = "warning"

                advice = (
                    "Moderate yield potential detected. "
                    "Improve nitrogen availability using CAN or Urea, "
                    "increase organic matter, and monitor phosphorus levels."
                )

            elif "low" in pred:

                bg_color = "danger"

                if ph < 5.5:

                    advice = (
                        f"Soil pH ({ph}) indicates acidic conditions. "
                        "Apply agricultural lime to improve nutrient availability "
                        "before planting."
                    )

                else:

                    advice = (
                        "Low yield potential detected. "
                        "Improve soil fertility using organic manure, "
                        "balanced NPK fertilizer, and proper nutrient management."
                    )

            else:

                bg_color = "info"

                advice = "Prediction generated successfully."

        except Exception as e:

            prediction = "Prediction Error"

            advice = str(e)

            bg_color = "danger"

    return render_template(
        "index.html",
        prediction=prediction,
        advice=advice,
        bg_color=bg_color
    )


if __name__ == "__main__":
    app.run(debug=True)